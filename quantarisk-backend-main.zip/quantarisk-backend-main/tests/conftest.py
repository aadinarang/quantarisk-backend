from __future__ import annotations

import os
from datetime import date, timedelta

import numpy as np
import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

# Force test DB before importing app modules
TEST_DATABASE_URL = "sqlite:///./test_quantarisk.db"
os.environ["DATABASE_URL"] = TEST_DATABASE_URL

from app.db import Base, Symbol, PriceRecord, FinancialRatio, DataQualityRecord
from app.main import app, get_db


engine = create_engine(
    TEST_DATABASE_URL,
    connect_args={"check_same_thread": False},
)
TestingSessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)


def seed_test_data():
    db = TestingSessionLocal()
    try:
        symbols = [
            ("AAPL", "Apple Inc.", "Technology", "NASDAQ"),
            ("MSFT", "Microsoft Corp", "Technology", "NASDAQ"),
            ("TSLA", "Tesla Inc.", "Automotive", "NASDAQ"),
        ]

        for symbol, name, sector, exchange in symbols:
            db.add(Symbol(
                symbol=symbol,
                name=name,
                sector=sector,
                exchange=exchange,
                market_cap="1.00T",
                price=100.0,
                change=1.0,
                change_pct=1.0,
            ))

        start = date(2024, 1, 1)
        rng = np.random.default_rng(42)

        for symbol, *_ in symbols:
            price = 100.0
            for i in range(320):
                d = start + timedelta(days=i)
                if d.weekday() >= 5:
                    continue
                ret = rng.normal(0, 0.01)
                price = max(1.0, price * np.exp(ret))
                high = price * 1.01
                low = price * 0.99
                db.add(PriceRecord(
                    symbol=symbol,
                    date=d,
                    open=price,
                    high=high,
                    low=low,
                    close=price,
                    volume=1_000_000,
                ))

            db.add(FinancialRatio(
                symbol=symbol,
                pe=20.0,
                eps=5.0,
                pb=6.0,
                ps=7.0,
                debt_to_equity=1.0,
                current_ratio=1.2,
                roe=0.15,
                roa=0.08,
                gross_margin=0.40,
                operating_margin=0.25,
                net_margin=0.20,
                dividend_yield=0.01,
                beta=1.1,
                sharpe_ratio=1.0,
                max_drawdown=0.2,
            ))

            db.add(DataQualityRecord(
                symbol=symbol,
                total_records=250,
                missing_values=0,
                date_gaps=0,
                price_range_violations=0,
                status="PASS",
                completeness=0.99,
            ))

        db.commit()
    finally:
        db.close()


@pytest.fixture(scope="session", autouse=True)
def setup_database():
    Base.metadata.drop_all(bind=engine)
    Base.metadata.create_all(bind=engine)
    seed_test_data()
    yield
    Base.metadata.drop_all(bind=engine)


def override_get_db():
    db = TestingSessionLocal()
    try:
        yield db
    finally:
        db.close()


app.dependency_overrides[get_db] = override_get_db


@pytest.fixture
def client():
    with TestClient(app) as c:
        yield c