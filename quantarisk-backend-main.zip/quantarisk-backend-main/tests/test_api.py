"""Integration tests — all 13 endpoints via FastAPI TestClient."""
import pytest


# ── 1. Symbols ────────────────────────────────────────────────────
def test_get_symbols_returns_list(client):
    r = client.get("/api/symbols")
    assert r.status_code == 200
    assert isinstance(r.json(), list)


def test_get_symbols_schema(client):
    r = client.get("/api/symbols")
    if r.json():
        s = r.json()[0]
        assert "symbol" in s and "name" in s


def test_search_symbols_returns_list(client):
    r = client.get("/api/symbols/search?q=a")
    assert r.status_code == 200
    assert isinstance(r.json(), list)


def test_search_symbols_missing_param(client):
    r = client.get("/api/symbols/search")
    assert r.status_code == 422


# ── 2. Risk overview ─────────────────────────────────────────────
def test_risk_overview_schema(client):
    r = client.get("/api/risk/overview")
    assert r.status_code == 200
    d = r.json()
    for key in ("totalSymbols", "highRiskCount", "mediumRiskCount", "lowRiskCount", "lastUpdated"):
        assert key in d


# ── 3. Snapshot ──────────────────────────────────────────────────
def test_risk_snapshot_missing_param(client):
    r = client.get("/api/risk/snapshot")
    assert r.status_code == 422


def test_risk_snapshot_schema(client):
    r = client.get("/api/risk/snapshot?symbol=AAPL")
    assert r.status_code in (200, 404)
    if r.status_code == 200:
        d = r.json()
        assert d["currentRisk"] in ("LOW", "MEDIUM", "HIGH")
        assert d["currentVolatility"] >= 0


# ── 4. History ───────────────────────────────────────────────────
def test_risk_history_schema(client):
    r = client.get("/api/risk/history?symbol=AAPL")
    assert r.status_code == 200
    d = r.json()
    assert "symbol" in d and "points" in d
    assert isinstance(d["points"], list)


# ── 5. Sectors ───────────────────────────────────────────────────
def test_sector_risk_returns_list(client):
    r = client.get("/api/risk/sectors")
    assert r.status_code == 200
    assert isinstance(r.json(), list)


# ── 6. Correlation ───────────────────────────────────────────────
def test_correlation_schema(client):
    r = client.get("/api/risk/correlation")
    assert r.status_code == 200
    d = r.json()
    assert "symbols" in d and "matrix" in d
    assert isinstance(d["symbols"], list)
    assert isinstance(d["matrix"], list)


def test_correlation_diagonal_is_one(client):
    r = client.get("/api/risk/correlation")
    d = r.json()
    matrix = d["matrix"]
    for i in range(len(matrix)):
        if len(matrix[i]) > i:
            assert abs(matrix[i][i] - 1.0) < 0.01


# ── 7. VaR ──────────────────────────────────────────────────────
def test_var_missing_param(client):
    r = client.get("/api/risk/var")
    assert r.status_code == 422


def test_var_schema(client):
    r = client.get("/api/risk/var?symbol=AAPL")
    assert r.status_code in (200, 404)
    if r.status_code == 200:
        d = r.json()
        assert "var95" in d and "var99" in d and "cvar95" in d
        assert d["var95"] >= 0 and d["var99"] >= 0


# ── 8. Drift summary ─────────────────────────────────────────────
def test_drift_summary_returns_list(client):
    r = client.get("/api/drift/summary")
    assert r.status_code == 200
    assert isinstance(r.json(), list)


# ── 9. Ratios ────────────────────────────────────────────────────
def test_ratios_missing_param(client):
    r = client.get("/api/ratios")
    assert r.status_code == 422


def test_ratios_schema(client):
    r = client.get("/api/ratios?symbol=AAPL")
    assert r.status_code in (200, 404)
    if r.status_code == 200:
        d = r.json()
        assert "pe" in d and "beta" in d and "maxDrawdown" in d


# ── 10. Data quality ─────────────────────────────────────────────
def test_data_quality_returns_list(client):
    r = client.get("/api/data-quality")
    assert r.status_code == 200
    assert isinstance(r.json(), list)


def test_data_quality_schema(client):
    r = client.get("/api/data-quality")
    if r.json():
        d = r.json()[0]
        assert "symbol" in d and "status" in d
        assert d["status"] in ("PASS", "WARN", "FAIL")
        assert 0.0 <= d["completeness"] <= 1.0


# ── 11. Alerts ───────────────────────────────────────────────────
def test_alerts_returns_list(client):
    r = client.get("/api/alerts")
    assert r.status_code == 200
    assert isinstance(r.json(), list)


# ── 12. Predict ──────────────────────────────────────────────────
def test_predict_missing_param(client):
    r = client.get("/api/predict")
    assert r.status_code == 422


def test_predict_schema(client):
    r = client.get("/api/predict?symbol=AAPL&days=10")
    assert r.status_code in (200, 404)
    if r.status_code == 200:
        d = r.json()
        assert "forecastDates" in d
        assert "forecastPrices" in d
        assert len(d["forecastPrices"]) == 10
        assert "modelVersion" in d


def test_predict_days_capped(client):
    r = client.get("/api/predict?symbol=AAPL&days=50")
    assert r.status_code == 422


# ── 13. Health ───────────────────────────────────────────────────
def test_health_returns_ok(client):
    r = client.get("/api/health")
    assert r.status_code == 200
    d = r.json()
    assert d["status"] == "ok"
    assert "db_connected" in d
    assert "model_loaded" in d