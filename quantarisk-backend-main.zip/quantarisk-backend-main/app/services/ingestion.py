"""
Data ingestion pipeline.
Fetches OHLCV + metadata from yfinance, validates, stores,
and computes per-symbol data quality records.
"""
from .data_quality import validate_ohlcv, count_null_values, count_date_gaps, count_price_range_violations
from datetime import date, timedelta, datetime
import yfinance as yf
import pandas as pd
from sqlalchemy.orm import Session
from ..db import SessionLocal, PriceRecord, Symbol, FinancialRatio, init_db
from .data_quality import (
    compute_data_quality,
    validate_ohlcv,
)


WATCHLIST = {
    "AAPL":  "Apple Inc.",
    "MSFT":  "Microsoft Corp",
    "TSLA":  "Tesla Inc.",
    "SPY":   "SPDR S&P 500 ETF",
    "NVDA":  "NVIDIA Corp",
    "AMZN":  "Amazon.com Inc.",
    "GOOGL": "Alphabet Inc.",
    "META":  "Meta Platforms Inc.",
    "JPM":   "JPMorgan Chase & Co.",
    "V":     "Visa Inc.",
}


# ── Symbol seeding & metadata enrichment ─────────────────────────

def seed_symbols(db: Session) -> None:
    """Seed the symbols table with watchlist entries if not present."""
    for symbol, name in WATCHLIST.items():
        if not db.query(Symbol).filter_by(symbol=symbol).first():
            db.add(Symbol(symbol=symbol, name=name))
    db.commit()


def enrich_symbol_metadata(db: Session, symbol: str) -> None:
    """
    Fetch sector, exchange, market cap, and latest price from
    yfinance Ticker.info and update the symbols table row.
    """
    try:
        ticker = yf.Ticker(symbol)
        info   = ticker.info or {}

        row = db.query(Symbol).filter_by(symbol=symbol).first()
        if not row:
            return

        row.sector     = info.get("sector", "Unknown") or "Unknown"
        row.exchange   = info.get("exchange", "Unknown") or "Unknown"
        mc = info.get("marketCap")
        if mc:
            if mc >= 1e12:
                row.market_cap = f"{mc/1e12:.2f}T"
            elif mc >= 1e9:
                row.market_cap = f"{mc/1e9:.2f}B"
            else:
                row.market_cap = f"{mc/1e6:.0f}M"
        row.price      = float(info.get("currentPrice") or info.get("regularMarketPrice") or 0)
        row.change     = float(info.get("regularMarketChange") or 0)
        row.change_pct = float(info.get("regularMarketChangePercent") or 0)
        db.commit()
    except Exception as e:
        print(f"[metadata] Warning: could not enrich {symbol}: {e}")


def enrich_financial_ratios(db: Session, symbol: str) -> None:
    """
    Fetch 15 fundamental and risk-adjusted ratios from yfinance Ticker.info
    and upsert into the financial_ratios table.
    """
    try:
        info = yf.Ticker(symbol).info or {}

        def safe(key, default=0.0):
            v = info.get(key)
            return float(v) if v is not None else default

        row = db.query(FinancialRatio).filter_by(symbol=symbol).first()
        if not row:
            row = FinancialRatio(symbol=symbol)
            db.add(row)

        row.pe               = safe("trailingPE")
        row.eps              = safe("trailingEps")
        row.pb               = safe("priceToBook")
        row.ps               = safe("priceToSalesTrailing12Months")
        row.debt_to_equity   = safe("debtToEquity")
        row.current_ratio    = safe("currentRatio")
        row.roe              = safe("returnOnEquity")
        row.roa              = safe("returnOnAssets")
        row.gross_margin     = safe("grossMargins")
        row.operating_margin = safe("operatingMargins")
        row.net_margin       = safe("profitMargins")
        row.dividend_yield   = safe("dividendYield")
        row.beta             = safe("beta")
        # Sharpe and max drawdown are not in Ticker.info — use 0 as placeholder
        row.sharpe_ratio     = 0.0
        row.max_drawdown     = 0.0
        row.updated_at       = datetime.utcnow()
        db.commit()
    except Exception as e:
        print(f"[ratios] Warning: could not fetch ratios for {symbol}: {e}")


# ── OHLCV ingestion ───────────────────────────────────────────────

def fetch_and_store_prices(db: Session, period_days: int = 365) -> None:
    """Download OHLCV history for all watchlist symbols and persist to DB."""
    start = date.today() - timedelta(days=period_days)

    for symbol in WATCHLIST:
        try:
            df = yf.download(symbol, start=start.isoformat(), auto_adjust=True, progress=False)
            if df.empty:
                print(f"[ingest] No data for {symbol}")
                continue

            # Flatten MultiIndex columns (yfinance quirk in newer versions)
            if isinstance(df.columns, pd.MultiIndex):
                df.columns = [col[0] for col in df.columns]

            df.reset_index(inplace=True)
            df.columns = [c.lower() for c in df.columns]
            df["date"] = pd.to_datetime(df["date"]).dt.date

            # Validate the downloaded OHLCV frame before persistence
            errors = validate_ohlcv(df)
            if errors:
                print(f"[ingest] Validation failed for {symbol}: {errors}")
                continue

            # Drop obviously invalid rows before writing
            df = df.dropna(subset=["date", "close"])
            df = df[(df["close"] > 0) & (df["volume"] >= 0)]
            df = df[df["high"] >= df["low"]]
            df = df[(df["close"] >= df["low"]) & (df["close"] <= df["high"])]

            stored = 0
            for _, row in df.iterrows():
                record_date = row["date"]
                if not db.query(PriceRecord).filter_by(symbol=symbol, date=record_date).first():
                    db.add(PriceRecord(
                        symbol=symbol,
                        date=record_date,
                        open=float(row.get("open", 0) or 0),
                        high=float(row.get("high", 0) or 0),
                        low=float(row.get("low", 0) or 0),
                        close=float(row.get("close", 0) or 0),
                        volume=float(row.get("volume", 0) or 0),
                    ))
                    stored += 1
            db.commit()
            print(f"[ingest] {symbol}: stored {stored} new records")

        except Exception as e:
            print(f"[ingest] Error for {symbol}: {e}")


# ── Data quality persistence ─────────────────────────────────────

def update_data_quality(db: Session) -> None:
    """Compute and persist data quality records for all symbols."""
    from ..db import DataQualityRecord as DQRow
    for symbol in WATCHLIST:
        dq = compute_data_quality(db, symbol)
        row = db.query(DQRow).filter_by(symbol=symbol).first()
        if not row:
            row = DQRow(symbol=symbol)
            db.add(row)
        row.total_records          = dq["totalRecords"]
        row.missing_values         = dq["missingValues"]
        row.date_gaps              = dq["dateGaps"]
        row.price_range_violations = dq["priceRangeViolations"]
        row.last_ingested          = datetime.utcnow()
        row.status                 = dq["status"]
        row.completeness           = dq["completeness"]
    db.commit()
    print("[quality] Data quality records updated")


# ── Entry point ───────────────────────────────────────────────────

def run_ingestion() -> None:
    init_db()
    db = SessionLocal()
    try:
        print("[ingest] Starting ingestion pipeline…")
        seed_symbols(db)
        fetch_and_store_prices(db)

        for symbol in WATCHLIST:
            enrich_symbol_metadata(db, symbol)
            enrich_financial_ratios(db, symbol)

        update_data_quality(db)

        from .snapshot_jobs import refresh_all_snapshots
        refresh_all_snapshots(db)

        print("[ingest] Pipeline complete.")
    finally:
        db.close()


if __name__ == "__main__":
    run_ingestion()
