"""Core analytics: volatility computation, risk classification, snapshots, history."""
import pandas as pd
import numpy as np
from sqlalchemy.orm import Session
from ..db import PriceRecord
from .drift import compute_drift
from .garch import fit_garch_forecast


# ── Price loading ─────────────────────────────────────────────────

def get_prices_df(db: Session, symbol: str) -> pd.DataFrame:
    """Return a DataFrame with columns [close] indexed by date."""
    records = (
        db.query(PriceRecord)
        .filter_by(symbol=symbol)
        .order_by(PriceRecord.date)
        .all()
    )
    if not records:
        return pd.DataFrame()

    df = pd.DataFrame([{"date": r.date, "close": r.close} for r in records])
    df["date"] = pd.to_datetime(df["date"])
    df.set_index("date", inplace=True)
    return df

def get_ohlcv_df(db: Session, symbol: str) -> pd.DataFrame:
    """
    Return a DataFrame with columns:
    open, high, low, close, volume
    indexed by date.
    """
    records = (
        db.query(PriceRecord)
        .filter_by(symbol=symbol)
        .order_by(PriceRecord.date)
        .all()
    )
    if not records:
        return pd.DataFrame()

    df = pd.DataFrame([{
        "date": r.date,
        "open": r.open,
        "high": r.high,
        "low": r.low,
        "close": r.close,
        "volume": r.volume,
    } for r in records])

    df["date"] = pd.to_datetime(df["date"])
    df.set_index("date", inplace=True)
    return df

def get_price_series(db: Session, symbol: str) -> pd.Series:
    """Return just the close price Series indexed by date."""
    df = get_prices_df(db, symbol)
    return df["close"] if not df.empty else pd.Series(dtype=float)


# ── Volatility ────────────────────────────────────────────────────

def compute_volatility(df: pd.DataFrame, window: int = 20) -> pd.Series:
    """
    20-day rolling standard deviation of daily log returns.
    Window is configurable (defaults match report specification).
    """
    log_returns = np.log(df["close"] / df["close"].shift(1))
    return log_returns.rolling(window=window).std()


# ── Risk classification ───────────────────────────────────────────

def classify_risk(
    current_vol: float,
    historical_vol: pd.Series,
    low_q: float = 0.5,
    high_q: float = 0.8,
) -> str:
    """
    Classify current volatility as LOW / MEDIUM / HIGH using quantile
    boundaries derived from the symbol's own historical volatility.
    This makes classification relative, not absolute.
    """
    low_threshold  = historical_vol.quantile(low_q)
    high_threshold = historical_vol.quantile(high_q)
    if current_vol <= low_threshold:
        return "LOW"
    elif current_vol <= high_threshold:
        return "MEDIUM"
    else:
        return "HIGH"


# ── Snapshot ──────────────────────────────────────────────────────

def get_snapshot(db: Session, symbol: str, window: int = 20,
                 low_q: float = 0.5, high_q: float = 0.8) -> dict:
    """
    Compute the current risk snapshot for one symbol.
    Uses GARCH(1,1) if ≥252 days of data are available,
    otherwise falls back to rolling standard deviation.
    """
    df = get_prices_df(db, symbol)
    if df.empty:
        return {}

    log_returns  = np.log(df["close"] / df["close"].shift(1)).dropna()
    rolling_vol  = compute_volatility(df, window=window).dropna()

    if rolling_vol.empty:
        return {}

    # Attempt GARCH upgrade
    vol_source   = "rolling"
    current_vol  = float(rolling_vol.iloc[-1])

    if len(log_returns) >= 252:
        garch_vol = fit_garch_forecast(log_returns)
        if garch_vol is not None and garch_vol > 0:
            current_vol = garch_vol
            vol_source  = "garch"

    risk_level              = classify_risk(current_vol, rolling_vol, low_q, high_q)
    drift_flag, drift_score = compute_drift(rolling_vol)

    return {
        "symbol":            symbol,
        "currentRisk":       risk_level,
        "currentVolatility": round(current_vol, 6),
        "driftFlag":         drift_flag,
        "driftScore":        round(drift_score, 4),
        "volSource":         vol_source,
    }


# ── History ───────────────────────────────────────────────────────

def get_history(db: Session, symbol: str, window: int = 20,
                low_q: float = 0.5, high_q: float = 0.8) -> dict:
    """
    Return the full time series of (date, volatility, riskLevel) for one symbol.
    Used by the volatility chart on the frontend.
    """
    df = get_prices_df(db, symbol)
    if df.empty:
        return {"symbol": symbol, "points": []}

    vol_series     = compute_volatility(df, window=window).dropna()
    historical_vol = vol_series

    points = []
    for dt, vol in vol_series.items():
        risk = classify_risk(float(vol), historical_vol, low_q, high_q)
        points.append({
            "date":       dt.strftime("%Y-%m-%d"),
            "volatility": round(float(vol), 6),
            "riskLevel":  risk,
        })

    return {"symbol": symbol, "points": points}
