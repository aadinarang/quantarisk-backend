"""Pydantic v2 response models — the complete API contract."""
from typing import List, Literal, Optional
from pydantic import BaseModel

RiskLevel    = Literal["LOW", "MEDIUM", "HIGH"]
AlertType    = Literal["DRIFT_DETECTED", "DRIFT_RESOLVED", "RISK_LEVEL_CHANGE", "VOLATILITY_SPIKE"]
AlertSeverity = Literal["HIGH", "MEDIUM", "LOW"]
QualityStatus = Literal["PASS", "WARN", "FAIL"]


# ── Symbol ──────────────────────────────────────────────
class SymbolInfo(BaseModel):
    symbol:        str
    name:          str
    sector:        str = "Unknown"
    exchange:      str = "Unknown"
    marketCap:     str = "N/A"
    price:         float = 0.0
    change:        float = 0.0
    changePercent: float = 0.0


# ── Risk ────────────────────────────────────────────────
class RiskOverview(BaseModel):
    totalSymbols:    int
    highRiskCount:   int
    mediumRiskCount: int
    lowRiskCount:    int
    lastUpdated:     str


class SymbolSnapshot(BaseModel):
    symbol:            str
    currentRisk:       RiskLevel
    currentVolatility: float
    driftFlag:         bool
    driftScore:        float
    volSource:         str = "rolling"   # "rolling" | "garch"


class HistoryPoint(BaseModel):
    date:       str
    volatility: float
    riskLevel:  RiskLevel


class SymbolHistory(BaseModel):
    symbol: str
    points: List[HistoryPoint]


class DriftSummaryItem(BaseModel):
    symbol:    str
    driftFlag: bool
    driftScore: float


# ── Sector / Correlation ────────────────────────────────
class SectorRiskBreakdown(BaseModel):
    sector: str
    high:   int
    medium: int
    low:    int
    total:  int


class CorrelationMatrix(BaseModel):
    symbols: List[str]
    matrix:  List[List[float]]   # NxN Pearson correlations


# ── VaR ─────────────────────────────────────────────────
class VaREstimate(BaseModel):
    symbol:  str
    var95:   float    # 1-day VaR at 95% as a positive decimal (e.g. 0.021 = 2.1%)
    var99:   float    # 1-day VaR at 99%
    cvar95:  float    # Conditional VaR / Expected Shortfall at 95%


# ── Financial Ratios ────────────────────────────────────
class SymbolRatios(BaseModel):
    pe:               float
    eps:              float
    pb:               float
    ps:               float
    debtToEquity:     float
    currentRatio:     float
    roe:              float
    roa:              float
    grossMargin:      float
    operatingMargin:  float
    netMargin:        float
    dividendYield:    float
    beta:             float
    sharpeRatio:      float
    maxDrawdown:      float


# ── Alerts ──────────────────────────────────────────────
class AlertItem(BaseModel):
    id:        str
    timestamp: str
    symbol:    str
    type:      AlertType
    severity:  AlertSeverity
    message:   str
    detail:    str
    read:      bool


# ── Data Quality ────────────────────────────────────────
class DataQualityRecord(BaseModel):
    symbol:               str
    totalRecords:         int
    missingValues:        int
    dateGaps:             int
    priceRangeViolations: int
    lastIngested:         str
    status:               QualityStatus
    completeness:         float   # 0.0 – 1.0


# ── LSTM Price Forecast ─────────────────────────────────
class PriceForecast(BaseModel):
    symbol:        str
    forecastDates: List[str]     # ISO date strings for each forecast step
    forecastPrices: List[float]  # Point predictions (price space)
    upperBand:     List[float]   # 95th percentile MC Dropout
    lowerBand:     List[float]   # 5th percentile MC Dropout
    modelVersion:  str           # e.g. "math-v1" or "lstm-v1"


# ── Health ──────────────────────────────────────────────
class HealthResponse(BaseModel):
    status: str
    uptime: float
    db_connected: bool
    model_loaded: bool
    build_version: str
    modelStatus: str = ""
    modelReason: str = ""
    modelVersion: str = "math-v1"

# ── Auth / User ───────────────────────────────────────────
class RegisterRequest(BaseModel):
    email: str
    displayName: str
    password: str


class LoginRequest(BaseModel):
    email: str
    password: str


class TokenResponse(BaseModel):
    accessToken: str
    tokenType: str = "bearer"


class UserProfile(BaseModel):
    id: int
    email: str
    displayName: str
    isActive: bool

class UserProfileUpdate(BaseModel):
    displayName: str
    email: str


class DeleteAccountRequest(BaseModel):
    password: str


# ── Watchlist ─────────────────────────────────────────────
class WatchlistAddRequest(BaseModel):
    symbol: str


class WatchlistItemResponse(BaseModel):
    symbol: str
    createdAt: str


# ── Settings ──────────────────────────────────────────────
class UserSettingsResponse(BaseModel):
    theme: str
    lowQuantile: float
    highQuantile: float
    volWindow: int
    driftRecentWindow: int
    driftReferenceWindow: int
    emailAlerts: bool
    driftEmailAlerts: bool
    updatedAt: str


class UserSettingsUpdate(BaseModel):
    theme: str = "light"
    lowQuantile: float = 0.5
    highQuantile: float = 0.8
    volWindow: int = 20
    driftRecentWindow: int = 30
    driftReferenceWindow: int = 180
    emailAlerts: bool = False
    driftEmailAlerts: bool = False


# ── User Alerts ───────────────────────────────────────────
class UserAlertItem(BaseModel):
    id: str
    timestamp: str
    symbol: str
    type: str
    severity: str
    message: str
    detail: str
    read: bool