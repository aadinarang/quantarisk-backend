"""
QuantaRisk FastAPI backend — complete API with all 13 endpoints.
All routes are prefixed /api/ and return Pydantic-validated JSON.
"""
import os
import time
from contextlib import asynccontextmanager
from datetime import datetime

from fastapi import FastAPI, Query, HTTPException, Depends
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session

from .db import (
    SessionLocal,
    Symbol,
    Alert as AlertRow,
    FinancialRatio,
    DataQualityRecord as DQRow,
    WatchlistItem,
    UserSettings,
    User,
    init_db,
)
from .models import (
    SymbolInfo, RiskOverview, SymbolSnapshot, SymbolHistory,
    DriftSummaryItem, SectorRiskBreakdown, CorrelationMatrix,
    VaREstimate, SymbolRatios, DataQualityRecord, AlertItem,
    PriceForecast, HealthResponse,
    RegisterRequest, LoginRequest, TokenResponse, UserProfile,
    WatchlistAddRequest, WatchlistItemResponse,
    UserSettingsResponse, UserSettingsUpdate,
    UserAlertItem, UserProfileUpdate, DeleteAccountRequest,
)
from .services.analytics import get_snapshot, get_history, get_price_series, get_ohlcv_df
from .services.var import compute_var
from .services.correlation import compute_correlation_matrix
from .services.alerts import (
    get_alerts,
    mark_alert_read,
    mark_all_read,
    get_alerts_for_user,
    mark_alert_read_for_user,
    mark_all_read_for_user,
)
from .services.predict import generate_forecast
from .services.model_registry import model_registry
from .services.auth import (
    hash_password,
    create_access_token,
    authenticate_user,
    get_current_user,
    verify_password,
)

_START_TIME = time.time()


# ── Lifespan ──────────────────────────────────────────────────────
@asynccontextmanager
async def lifespan(app: FastAPI):
    """Initialise DB, load model, and run ingestion on startup."""
    init_db()

    # Load forecasting model at startup
    try:
        model_registry.load_startup_models()
    except Exception as e:
        print(f"[startup] Model load warning: {e}")

    # Run ingestion on startup
    try:
        from .services.ingestion import run_ingestion
        run_ingestion()
    except Exception as e:
        print(f"[startup] Ingestion warning: {e}")

    yield


app = FastAPI(
    title="QuantaRisk API",
    version="1.0.0",
    description="Intelligent equity risk analytics — volatility, drift, VaR, and LSTM forecasting.",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],         # tighten to frontend origin in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ── DB dependency ────────────────────────────────────────────────
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


# ── Helper ───────────────────────────────────────────────────────
def _symbol_to_info(s: Symbol) -> SymbolInfo:
    return SymbolInfo(
        symbol=s.symbol,
        name=s.name,
        sector=s.sector or "Unknown",
        exchange=s.exchange or "Unknown",
        marketCap=s.market_cap or "N/A",
        price=s.price or 0.0,
        change=s.change or 0.0,
        changePercent=s.change_pct or 0.0,
    )

def _ensure_user_settings(db: Session, user_id: int) -> UserSettings:
    row = db.query(UserSettings).filter_by(user_id=user_id).first()
    if not row:
        row = UserSettings(
            user_id=user_id,
            theme="light",
            low_quantile=0.5,
            high_quantile=0.8,
            vol_window=20,
            drift_recent_window=30,
            drift_reference_window=180,
            email_alerts=False,
            drift_email_alerts=False,
            updated_at=datetime.utcnow(),
        )
        db.add(row)
        db.commit()
        db.refresh(row)
    return row
# ════════════════════════════════════════════════════════════════
# Endpoints
# ════════════════════════════════════════════════════════════════
@app.post("/api/auth/register", response_model=UserProfile)
def register_user(payload: RegisterRequest, db: Session = Depends(get_db)):
    existing = db.query(User).filter(User.email == payload.email).first()
    if existing:
        raise HTTPException(status_code=400, detail="Email already registered")

    user = User(
        email=payload.email.strip().lower(),
        display_name=payload.displayName.strip(),
        password_hash=hash_password(payload.password),
        is_active=True,
        created_at=datetime.utcnow(),
    )
    db.add(user)
    db.commit()
    db.refresh(user)

    _ensure_user_settings(db, user.id)

    return UserProfile(
        id=user.id,
        email=user.email,
        displayName=user.display_name,
        isActive=user.is_active,
    )


@app.post("/api/auth/login", response_model=TokenResponse)
def login_user(payload: LoginRequest, db: Session = Depends(get_db)):
    user = authenticate_user(db, payload.email.strip().lower(), payload.password)
    if not user:
        raise HTTPException(status_code=401, detail="Invalid email or password")

    token = create_access_token(user.id, user.email)
    return TokenResponse(accessToken=token, tokenType="bearer")


@app.get("/api/auth/me", response_model=UserProfile)
def get_me(current_user: User = Depends(get_current_user)):
    return UserProfile(
        id=current_user.id,
        email=current_user.email,
        displayName=current_user.display_name,
        isActive=current_user.is_active,
    )

@app.put("/api/account/profile", response_model=UserProfile)
def update_profile(
    payload: UserProfileUpdate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    new_email = payload.email.strip().lower()
    new_name = payload.displayName.strip()

    if not new_email:
        raise HTTPException(status_code=400, detail="Email cannot be empty")
    if not new_name:
        raise HTTPException(status_code=400, detail="Display name cannot be empty")

    existing = db.query(User).filter(
        User.email == new_email,
        User.id != current_user.id
    ).first()
    if existing:
        raise HTTPException(status_code=400, detail="Email already in use")

    current_user.email = new_email
    current_user.display_name = new_name
    db.commit()
    db.refresh(current_user)

    return UserProfile(
        id=current_user.id,
        email=current_user.email,
        displayName=current_user.display_name,
        isActive=current_user.is_active,
    )

@app.get("/api/watchlist", response_model=list[WatchlistItemResponse])
def get_watchlist(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    rows = (
        db.query(WatchlistItem)
        .filter_by(user_id=current_user.id)
        .order_by(WatchlistItem.created_at.desc())
        .all()
    )
    return [
        WatchlistItemResponse(
            symbol=row.symbol,
            createdAt=row.created_at.isoformat() + "Z",
        )
        for row in rows
    ]


@app.post("/api/watchlist", response_model=WatchlistItemResponse)
def add_watchlist_item(
    payload: WatchlistAddRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    symbol = payload.symbol.strip().upper()

    symbol_exists = db.query(Symbol).filter_by(symbol=symbol).first()
    if not symbol_exists:
        raise HTTPException(status_code=404, detail=f"Unknown symbol: {symbol}")

    existing = db.query(WatchlistItem).filter_by(user_id=current_user.id, symbol=symbol).first()
    if existing:
        return WatchlistItemResponse(
            symbol=existing.symbol,
            createdAt=existing.created_at.isoformat() + "Z",
        )

    row = WatchlistItem(
        user_id=current_user.id,
        symbol=symbol,
        created_at=datetime.utcnow(),
    )
    db.add(row)
    db.commit()
    db.refresh(row)

    return WatchlistItemResponse(
        symbol=row.symbol,
        createdAt=row.created_at.isoformat() + "Z",
    )


@app.delete("/api/watchlist/{symbol}")
def delete_watchlist_item(
    symbol: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    row = db.query(WatchlistItem).filter_by(
        user_id=current_user.id,
        symbol=symbol.upper(),
    ).first()

    if not row:
        raise HTTPException(status_code=404, detail="Watchlist item not found")

    db.delete(row)
    db.commit()
    return {"ok": True}

@app.get("/api/settings", response_model=UserSettingsResponse)
def get_settings(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    row = _ensure_user_settings(db, current_user.id)
    return UserSettingsResponse(
        theme=row.theme,
        lowQuantile=row.low_quantile,
        highQuantile=row.high_quantile,
        volWindow=row.vol_window,
        driftRecentWindow=row.drift_recent_window,
        driftReferenceWindow=row.drift_reference_window,
        emailAlerts=row.email_alerts,
        driftEmailAlerts=row.drift_email_alerts,
        updatedAt=row.updated_at.isoformat() + "Z",
    )


@app.put("/api/settings", response_model=UserSettingsResponse)
def update_settings(
    payload: UserSettingsUpdate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    if payload.lowQuantile >= payload.highQuantile:
        raise HTTPException(status_code=400, detail="lowQuantile must be less than highQuantile")

    row = _ensure_user_settings(db, current_user.id)
    row.theme = payload.theme
    row.low_quantile = payload.lowQuantile
    row.high_quantile = payload.highQuantile
    row.vol_window = payload.volWindow
    row.drift_recent_window = payload.driftRecentWindow
    row.drift_reference_window = payload.driftReferenceWindow
    row.email_alerts = payload.emailAlerts
    row.drift_email_alerts = payload.driftEmailAlerts
    row.updated_at = datetime.utcnow()

    db.commit()
    db.refresh(row)

    return UserSettingsResponse(
        theme=row.theme,
        lowQuantile=row.low_quantile,
        highQuantile=row.high_quantile,
        volWindow=row.vol_window,
        driftRecentWindow=row.drift_recent_window,
        driftReferenceWindow=row.drift_reference_window,
        emailAlerts=row.email_alerts,
        driftEmailAlerts=row.drift_email_alerts,
        updatedAt=row.updated_at.isoformat() + "Z",
    )

@app.get("/api/me/alerts", response_model=list[UserAlertItem])
def my_alerts(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    return [UserAlertItem(**a) for a in get_alerts_for_user(db, current_user.id)]


@app.patch("/api/me/alerts/{alert_id}/read")
def my_alert_read(
    alert_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    if not mark_alert_read_for_user(db, current_user.id, alert_id):
        raise HTTPException(status_code=404, detail="Alert not found")
    return {"ok": True}


@app.patch("/api/me/alerts/read-all")
def my_alerts_read_all(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    count = mark_all_read_for_user(db, current_user.id)
    return {"marked": count}


# 1. GET /api/symbols
@app.get("/api/symbols", response_model=list[SymbolInfo])
def list_symbols(db: Session = Depends(get_db)):
    """All tracked symbols with price, change %, sector, exchange, market cap."""
    return [_symbol_to_info(s) for s in db.query(Symbol).all()]


# 2. GET /api/symbols/search
@app.get("/api/symbols/search", response_model=list[SymbolInfo])
def search_symbols(q: str = Query(..., min_length=1), db: Session = Depends(get_db)):
    """Case-insensitive substring search by ticker or company name."""
    q_lower = q.lower()
    symbols = db.query(Symbol).all()
    return [
        _symbol_to_info(s) for s in symbols
        if q_lower in s.symbol.lower() or q_lower in (s.name or "").lower()
    ]


# 3. GET /api/risk/overview
@app.get("/api/risk/overview", response_model=RiskOverview)
def risk_overview(db: Session = Depends(get_db)):
    """Aggregate counts: total, high, medium, low risk symbols + last updated timestamp."""
    symbols = db.query(Symbol).all()
    counts  = {"LOW": 0, "MEDIUM": 0, "HIGH": 0}
    for s in symbols:
        snap = get_snapshot(db, s.symbol)
        if snap:
            counts[snap["currentRisk"]] += 1
    return RiskOverview(
        totalSymbols=len(symbols),
        highRiskCount=counts["HIGH"],
        mediumRiskCount=counts["MEDIUM"],
        lowRiskCount=counts["LOW"],
        lastUpdated=datetime.utcnow().isoformat() + "Z",
    )


# 4. GET /api/risk/snapshot
@app.get("/api/risk/snapshot", response_model=SymbolSnapshot)
def risk_snapshot(
    symbol: str = Query(...),
    window: int = Query(20),
    low_q:  float = Query(0.5),
    high_q: float = Query(0.8),
    db: Session = Depends(get_db),
):
    """Current volatility, risk level, drift flag and KS score for one symbol."""
    snap = get_snapshot(db, symbol, window=window, low_q=low_q, high_q=high_q)
    if not snap:
        raise HTTPException(status_code=404, detail=f"No data for symbol {symbol}")
    return SymbolSnapshot(**snap)


# 5. GET /api/risk/history
@app.get("/api/risk/history", response_model=SymbolHistory)
def risk_history(
    symbol: str   = Query(...),
    window: int   = Query(20),
    low_q:  float = Query(0.5),
    high_q: float = Query(0.8),
    db: Session = Depends(get_db),
):
    """Full time series of (date, volatility, riskLevel) for one symbol."""
    return get_history(db, symbol, window=window, low_q=low_q, high_q=high_q)


# 6. GET /api/risk/sectors
@app.get("/api/risk/sectors", response_model=list[SectorRiskBreakdown])
def sector_risk(db: Session = Depends(get_db)):
    """Per-sector counts of high, medium, low risk symbols."""
    symbols = db.query(Symbol).all()
    sector_map: dict = {}
    for s in symbols:
        snap = get_snapshot(db, s.symbol)
        if not snap:
            continue
        sec = s.sector or "Unknown"
        if sec not in sector_map:
            sector_map[sec] = {"high": 0, "medium": 0, "low": 0}
        sector_map[sec][snap["currentRisk"].lower()] += 1

    return [
        SectorRiskBreakdown(
            sector=sec,
            high=v["high"],
            medium=v["medium"],
            low=v["low"],
            total=v["high"] + v["medium"] + v["low"],
        )
        for sec, v in sector_map.items()
    ]


# 7. GET /api/risk/correlation
@app.get("/api/risk/correlation", response_model=CorrelationMatrix)
def correlation(db: Session = Depends(get_db)):
    """Pairwise Pearson correlation matrix across all symbol return series."""
    symbols = [s.symbol for s in db.query(Symbol).all()]
    result  = compute_correlation_matrix(db, symbols)
    return CorrelationMatrix(**result)


# 8. GET /api/risk/var
@app.get("/api/risk/var", response_model=VaREstimate)
def value_at_risk(symbol: str = Query(...), db: Session = Depends(get_db)):
    """1-day parametric VaR at 95% and 99% confidence, plus CVaR at 95%."""
    prices = get_price_series(db, symbol)
    if prices.empty:
        raise HTTPException(status_code=404, detail=f"No data for symbol {symbol}")
    var = compute_var(prices)
    return VaREstimate(symbol=symbol, **var)


# 9. GET /api/drift/summary
@app.get("/api/drift/summary", response_model=list[DriftSummaryItem])
def drift_summary(db: Session = Depends(get_db)):
    """KS drift flag and score for every tracked symbol."""
    symbols = db.query(Symbol).all()
    result  = []
    for s in symbols:
        snap = get_snapshot(db, s.symbol)
        if snap:
            result.append(DriftSummaryItem(
                symbol=s.symbol,
                driftFlag=snap["driftFlag"],
                driftScore=snap["driftScore"],
            ))
    return result


# 10. GET /api/ratios
@app.get("/api/ratios", response_model=SymbolRatios)
def financial_ratios(symbol: str = Query(...), db: Session = Depends(get_db)):
    """15 fundamental and risk-adjusted financial ratios for one symbol."""
    row = db.query(FinancialRatio).filter_by(symbol=symbol).first()
    if not row:
        raise HTTPException(status_code=404, detail=f"No ratio data for {symbol}")
    return SymbolRatios(
        pe=row.pe or 0.0,
        eps=row.eps or 0.0,
        pb=row.pb or 0.0,
        ps=row.ps or 0.0,
        debtToEquity=row.debt_to_equity or 0.0,
        currentRatio=row.current_ratio or 0.0,
        roe=row.roe or 0.0,
        roa=row.roa or 0.0,
        grossMargin=row.gross_margin or 0.0,
        operatingMargin=row.operating_margin or 0.0,
        netMargin=row.net_margin or 0.0,
        dividendYield=row.dividend_yield or 0.0,
        beta=row.beta or 0.0,
        sharpeRatio=row.sharpe_ratio or 0.0,
        maxDrawdown=row.max_drawdown or 0.0,
    )


# 11. GET /api/data-quality
@app.get("/api/data-quality", response_model=list[DataQualityRecord])
def data_quality(
    watchlist_only: bool = Query(False),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user) if False else None,
):
    """
    Per-symbol ingestion audit: completeness, gaps, violations, status.
    If watchlist_only=true is needed later, we can filter client-side or add a dedicated route.
    """
    rows = db.query(DQRow).all()
    if not rows:
        from .services.data_quality import compute_data_quality
        symbols = db.query(Symbol).all()
        result = []
        for s in symbols:
            dq = compute_data_quality(db, s.symbol)
            result.append(DataQualityRecord(
                symbol=dq["symbol"],
                totalRecords=dq["totalRecords"],
                missingValues=dq["missingValues"],
                dateGaps=dq["dateGaps"],
                priceRangeViolations=dq["priceRangeViolations"],
                lastIngested=dq["lastIngested"],
                status=dq["status"],
                completeness=dq["completeness"],
            ))
        return result

    return [
        DataQualityRecord(
            symbol=r.symbol,
            totalRecords=r.total_records or 0,
            missingValues=r.missing_values or 0,
            dateGaps=r.date_gaps or 0,
            priceRangeViolations=r.price_range_violations or 0,
            lastIngested=(r.last_ingested.isoformat() + "Z") if r.last_ingested else "",
            status=r.status or "PASS",
            completeness=r.completeness or 0.0,
        )
        for r in rows
    ]


# 12. GET /api/alerts
@app.get("/api/alerts", response_model=list[AlertItem])
def alerts(db: Session = Depends(get_db)):
    """Alert feed: drift events, risk changes, volatility spikes."""
    return [AlertItem(**a) for a in get_alerts(db)]


# 12b. PATCH /api/alerts/{alert_id}/read  (acknowledge single alert)
@app.patch("/api/alerts/{alert_id}/read")
def acknowledge_alert(alert_id: str, db: Session = Depends(get_db)):
    if not mark_alert_read(db, alert_id):
        raise HTTPException(status_code=404, detail="Alert not found")
    return {"ok": True}


# 12c. PATCH /api/alerts/read-all  (acknowledge all)
@app.patch("/api/alerts/read-all")
def acknowledge_all_alerts(db: Session = Depends(get_db)):
    count = mark_all_read(db)
    return {"marked": count}


# 13. GET /api/predict
@app.get("/api/predict", response_model=PriceForecast)
def predict(
    symbol: str = Query(...),
    days: int = Query(10, ge=1, le=30),
    db: Session = Depends(get_db),
):
    """LSTM-based forward price forecast with upper/lower confidence bands."""
    prices_df = get_ohlcv_df(db, symbol)
    if prices_df.empty:
        raise HTTPException(status_code=404, detail=f"No price data for {symbol}")
    return PriceForecast(**generate_forecast(symbol, prices_df, horizon=days))


# 14. POST Manual ingestion trigger
@app.post("/api/ingest/run")
def run_ingestion_now():
    from .services.ingestion import run_ingestion
    run_ingestion()
    return {"ok": True}


# 15. GET /api/health
@app.get("/api/health", response_model=HealthResponse)
def health(db: Session = Depends(get_db)):
    try:
        db.execute(__import__("sqlalchemy").text("SELECT 1"))
        db_ok = True
    except Exception:
        db_ok = False

    from .services.model_registry import model_registry
    model_info = model_registry.health_payload()

    return HealthResponse(
        status="ok",
        uptime=round(time.time() - _START_TIME, 1),
        db_connected=db_ok,
        model_loaded=model_info["model_loaded"],
        build_version=os.getenv("BUILD_VERSION", "dev"),
        modelStatus=model_info["model_status"],
        modelReason=model_info["model_reason"],
        modelVersion=model_info["model_version"],
    )


