import os
from sqlalchemy import (
    create_engine, Column, String, Float,
    Boolean, DateTime, Date, Integer, Text,
    ForeignKey, UniqueConstraint
)
from sqlalchemy.orm import declarative_base, sessionmaker
from dotenv import load_dotenv

load_dotenv()

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./quantarisk.db")
connect_args = {"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {}

engine = create_engine(DATABASE_URL, connect_args=connect_args)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)
Base = declarative_base()


class Symbol(Base):
    """Tracked symbol metadata and latest price snapshot."""
    __tablename__ = "symbols"
    symbol      = Column(String, primary_key=True)
    name        = Column(String)
    sector      = Column(String, default="Unknown")
    exchange    = Column(String, default="Unknown")
    market_cap  = Column(String, default="N/A")
    price       = Column(Float, default=0.0)
    change      = Column(Float, default=0.0)
    change_pct  = Column(Float, default=0.0)


class PriceRecord(Base):
    """Daily OHLCV records per symbol."""
    __tablename__ = "prices"
    id     = Column(Integer, primary_key=True, autoincrement=True)
    symbol = Column(String, index=True)
    date   = Column(Date, index=True)
    open   = Column(Float)
    high   = Column(Float)
    low    = Column(Float)
    close  = Column(Float)
    volume = Column(Float)


class RiskSnapshot(Base):
    """Materialised daily risk snapshot per symbol."""
    __tablename__ = "risk_snapshots"
    id          = Column(Integer, primary_key=True, autoincrement=True)
    symbol      = Column(String, index=True)
    date        = Column(Date)
    volatility  = Column(Float)
    risk_level  = Column(String)
    drift_flag  = Column(Boolean)
    drift_score = Column(Float)
    vol_source  = Column(String, default="rolling")
    computed_at = Column(DateTime)


class Alert(Base):
    """System-generated alert feed."""
    __tablename__ = "alerts"
    id        = Column(String, primary_key=True)   # UUID string
    timestamp = Column(DateTime, index=True)
    symbol    = Column(String, index=True)
    type      = Column(String)     # DRIFT_DETECTED | DRIFT_RESOLVED | RISK_LEVEL_CHANGE | VOLATILITY_SPIKE
    severity  = Column(String)     # HIGH | MEDIUM | LOW
    message   = Column(String)
    detail    = Column(Text)
    read      = Column(Boolean, default=False)


class FinancialRatio(Base):
    """Fundamental ratios per symbol (fetched from yfinance Ticker.info)."""
    __tablename__ = "financial_ratios"
    symbol            = Column(String, primary_key=True)
    pe                = Column(Float)
    eps               = Column(Float)
    pb                = Column(Float)
    ps                = Column(Float)
    debt_to_equity    = Column(Float)
    current_ratio     = Column(Float)
    roe               = Column(Float)
    roa               = Column(Float)
    gross_margin      = Column(Float)
    operating_margin  = Column(Float)
    net_margin        = Column(Float)
    dividend_yield    = Column(Float)
    beta              = Column(Float)
    sharpe_ratio      = Column(Float)
    max_drawdown      = Column(Float)
    updated_at        = Column(DateTime)


class DataQualityRecord(Base):
    """Per-symbol ingestion validation results."""
    __tablename__ = "data_quality"
    symbol                  = Column(String, primary_key=True)
    total_records           = Column(Integer)
    missing_values          = Column(Integer)
    date_gaps               = Column(Integer)
    price_range_violations  = Column(Integer)
    last_ingested           = Column(DateTime)
    status                  = Column(String)   # PASS | WARN | FAIL
    completeness            = Column(Float)    # 0.0 – 1.0

class User(Base):
    """Application user."""
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, autoincrement=True)
    email = Column(String, unique=True, index=True, nullable=False)
    display_name = Column(String, nullable=False)
    password_hash = Column(String, nullable=False)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime)


class WatchlistItem(Base):
    """Per-user watchlist items."""
    __tablename__ = "watchlist_items"
    __table_args__ = (
        UniqueConstraint("user_id", "symbol", name="uq_watchlist_user_symbol"),
    )

    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(Integer, ForeignKey("users.id"), index=True, nullable=False)
    symbol = Column(String, index=True, nullable=False)
    created_at = Column(DateTime)


class UserSettings(Base):
    """Per-user analytics and UI settings."""
    __tablename__ = "user_settings"

    user_id = Column(Integer, ForeignKey("users.id"), primary_key=True)
    theme = Column(String, default="light")
    low_quantile = Column(Float, default=0.5)
    high_quantile = Column(Float, default=0.8)
    vol_window = Column(Integer, default=20)
    drift_recent_window = Column(Integer, default=30)
    drift_reference_window = Column(Integer, default=180)
    email_alerts = Column(Boolean, default=False)
    drift_email_alerts = Column(Boolean, default=False)
    updated_at = Column(DateTime)


class UserAlertState(Base):
    """Per-user read state for global alerts."""
    __tablename__ = "user_alert_states"
    __table_args__ = (
        UniqueConstraint("user_id", "alert_id", name="uq_user_alert"),
    )

    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(Integer, ForeignKey("users.id"), index=True, nullable=False)
    alert_id = Column(String, ForeignKey("alerts.id"), index=True, nullable=False)
    read = Column(Boolean, default=False)
    read_at = Column(DateTime)

    
def init_db():
    Base.metadata.create_all(bind=engine)
